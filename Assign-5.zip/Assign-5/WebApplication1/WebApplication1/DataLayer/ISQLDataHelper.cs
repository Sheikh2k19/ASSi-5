﻿using SampleProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleProject.DataLayer
{
    public interface ISQLDataHelper
    {
        public List<Book> GetBooksData();//Testing Task ---get Detail of All the Books 
        public List<User> GetUsersData();//Testing Task ---get Detail of All the User
        public int EnterNewBook(Book newBook);// Task-1 ---Adding New Book to repository
        public int EnterNewUser(User newBook);// Task-1 ---Adding New User to repository
    }
}

