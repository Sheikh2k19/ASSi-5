﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Microsoft.Extensions.Configuration;
using SampleProject.Models;

namespace SampleProject.DataLayer
{
    public class SQLDataHelper : ISQLDataHelper
    {
        //Please add server, db, user and password below\
        // Building Connection -- StoreProcedure and Query to get detail of all book 
        string connectionString = "Data Source=CMDLHRDB01;Initial Catalog=4399AbdulSamad; Trusted_Connection=True";

        public SQLDataHelper()
        {
        }


        public SQLDataHelper(IConfiguration config)
        {
            var c = config;
            connectionString = config.GetConnectionString("4399AbdulSamad");
        }
        //StoreProcedure and Query to get detail of all book 
        public List<Book> GetBooksData()
        {
            List<Book> lstBook = new List<Book>();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("GetBooks", con);
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();

                while (sdr.Read())
                {
                    Book Book = new Book();

                    Book.ID = Convert.ToInt32(sdr["Id"]);
                    Book.Category = sdr["Category"].ToString();
                    Book.BookName = sdr["Name"].ToString();
                    Book.ShelfNumber = Convert.ToInt32(sdr["ShelfNumber"]);
                    Book.Price = Convert.ToInt32(sdr["Price"]);
                    Book.Status = Convert.ToInt32(sdr["AvailabilityStatus"]);
                    lstBook.Add(Book);
                }
                con.Close();
            }
            return lstBook;
        }
        //To Get Data of All users
        public List<User> GetUsersData()
        {
            List<User> lstUser = new List<User>();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("GetUser", con);
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();

                while (sdr.Read())
                {
                    User User = new User();

                    User.UserID = Convert.ToInt32(sdr["ID"]);
                   
                    User.Name = sdr["Name"].ToString();
                    
                    lstUser.Add(User);
                }
                con.Close();
            }
            return lstUser;
        }
        //Task-1--Adding new Book to Repository 
        public int EnterNewBook(Book newBook)
        {
           

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("AddBook", con);
                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = newBook.ID;
                cmd.Parameters.Add("@Category", SqlDbType.VarChar).Value = newBook.Category;
                cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = newBook.BookName;
                cmd.Parameters.Add("@ShelfNumber", SqlDbType.Int).Value = newBook.ShelfNumber;
                cmd.Parameters.Add("@Price", SqlDbType.Int).Value = newBook.Price;
                cmd.Parameters.Add("@Status", SqlDbType.Int).Value = newBook.Status;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
            return 1;
        }

        //Task-2--Adding new User to Repository 
        public int EnterNewUser(User newUser)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("AddUser", con);
                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = newUser.UserID;
                cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = newUser.Name;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
            return 1;
        }


    }
}
