﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SampleProject.DataLayer;
using SampleProject.Models;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        SQLDataHelper z=new SQLDataHelper();
        IBooksData _booksData;
        IUsersData _usersData;




        [HttpGet("getBooks")]
        public List<Book> GetBookData()
        {
            return z.GetBooksData();
        }
        [HttpGet("getUser")]
        public List<User> GetUserData()
        {
            return z.GetUsersData();
        }

        //Task-1
        [Route("AddBook")]
        [HttpPost]
        public int EnterNewBook([FromBody] Book newBook)
        {
            
        }
        //Task-2
        [HttpPut("addUser")]
        public int EnterNewUser(User newBook)
        {

        }
    }
}
