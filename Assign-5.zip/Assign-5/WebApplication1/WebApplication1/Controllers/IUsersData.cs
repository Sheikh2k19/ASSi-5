﻿namespace WebApplication1.Controllers
{
    internal interface IUsersData
    {
    }
}