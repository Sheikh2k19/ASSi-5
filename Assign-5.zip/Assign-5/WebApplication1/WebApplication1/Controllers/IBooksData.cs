﻿namespace WebApplication1.Controllers
{
    internal interface IBooksData
    {
    }
}