﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace SampleProject.Models
{
    public class Book
    {   // Making getter and setter of Book ID 
        public int ID { get; set; }
        // Making getter and setter of Book Category
        [Required(ErrorMessage = "Enter Book Category")]
        [StringLength(15, ErrorMessage = "Book Category should be less than or equal to Fifteen characters.")]
        public string Category { get; set; }
        // Making getter and setter of Book Name 
        [Required(ErrorMessage = "Enter Book Name")]
        [StringLength(50, ErrorMessage = "Book Name should be less than or equal to fifty characters.")]
        public string BookName { get; set; }
        // Making getter and setter of ShelfNumber 
        public int ShelfNumber { get; set; }
        // Making getter and setter of Book Price
        public int Price { get; set; }
        // Making getter and setter of Availibility Status
        
        public int Status { get; set; }
        
    }
}