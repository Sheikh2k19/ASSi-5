﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace SampleProject.Models
{
    public class User
    { // Making getter and setter of User ID 
        public int UserID { get; set; }
        // Making getter and setter of User Name
        [Required(ErrorMessage = "Enter  User Name ")]
        [StringLength(15, ErrorMessage = "User Name should be less than or equal to Fifteen characters.")]
        public string Name { get; set; }
        
    }
}